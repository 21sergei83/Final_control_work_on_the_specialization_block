package Java.Beasts;

interface Employable {
    void employ();
}

