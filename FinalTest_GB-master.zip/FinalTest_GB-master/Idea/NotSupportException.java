package Java;

public class NotSupportException extends RuntimeException {
    public NotSupportException(String s) {
        super(s);
    }
}
