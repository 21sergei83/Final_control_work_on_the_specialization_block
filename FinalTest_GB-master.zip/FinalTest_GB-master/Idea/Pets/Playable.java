package Java.Pets;

interface Playable {
    void play();
}
